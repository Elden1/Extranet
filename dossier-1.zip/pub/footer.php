<footer>
 <div class="foot_link">
 	<p><form>
<a href="admin_page.php">Confidentialité </a><br /> <a href="deconnexion.php">Mentions légales </a>
	</form></p>
</div>

</footer>
</html>
