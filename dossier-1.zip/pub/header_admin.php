<?php
include_once 'extra-config.php';
session_start();
 ?>
    <!DOCTYPE html>
<html>
<head>       
 <meta charset="utf-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link href="style.css" rel="stylesheet" /> 
<div id="head_info">
    <div class="img_header">
     <img src='logo\logoGbaf.png' width="100" alt='??'>
    </div>

    <div class="head_link"><p>
	   <form>    
<a href="deconnexion.php">Vous déconnecter</a><br/>
<a href="extra_gbaf.php">Retour à la page des articles</a>
	   </form>
    </div>
    </div>
